from django.shortcuts import render, redirect
from portal_app.forms import SignUp, SignIn
from portal_app.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login

# Create your views here.


def sign_up(request):
    if request.method == 'POST':
        form = SignUp(request.POST)
        if form.is_valid():
            user = User(
                username=form.cleaned_data.get('user_name'),
                name=form.cleaned_data.get('name'),
                email=form.cleaned_data.get('email'),
                phonenumber=form.cleaned_data.get('phone_number'),
                gender=form.cleaned_data.get('gender'),
                dob=form.cleaned_data.get('date_of_birth'),
                password=form.cleaned_data.get('password'),
                is_admin=0,
                is_staff=0,
                is_active=1

            )
            try:
                user.save()
                username = form.cleaned_data.get('user_name')
                messages.success(
                    request, f'Account created for {username}! You are now able to log in.')
                return redirect('log-in')
            except Exception as e:
                messages.warning(
                    request, f'The username or email is already taken.')
                return redirect('sign-up')

    else:
        form = SignUp()

    return render(request, 'sign_up.html', {"title": "Sign up", "form": form})


def log_in(request):
    if request.method == 'POST':
        form = SignIn(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('user_name')
            password = form.cleaned_data.get('password')
            try:
                user = User.objects.get(username=username, password=password)
            except User.DoesNotExist:
                user = None

            if user is not None:
                if user.is_active == 1:
                    if user.is_admin == 0 and user.is_staff == 0:
                        request.session['user_id'] = user.id
                        return redirect('general-user-dashboard')
                    elif user.is_admin == 1 and user.is_staff == 0:
                        request.session['user_id'] = user.id
                        return redirect('super-admin-user-dashboard')
                    else:
                        request.session['user_id'] = user.id
                        return redirect('normal-admin-user-dashboard')
                else:
                    messages.warning(
                        request, f'You are now not able to log in due to account is currently inactive!')
                    return redirect('log-in')
            else:
                messages.warning(
                    request, f'Invalid username or password!')
                return redirect('log-in')

    else:
        form = SignIn()

    return render(request, 'log_in.html', {"title": "Log in", "form": form})


def log_out(request):
    try:
        del request.session['user_id']
        messages.success(
            request, f'You are successfully logged out.')
        return redirect('log-in')
    except KeyError:
        messages.warning(
            request, f'No session found!')
        return redirect('log-in')

