from django.db import models

# Create your models here.


class User(models.Model):

    username = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=50, unique=True)
    phonenumber = models.CharField(max_length=14)
    gender = models.CharField(max_length=6)
    dob = models.DateField()
    password = models.CharField(max_length=33)
    is_admin = models.BooleanField()
    is_staff = models.BooleanField()
    is_active = models.BooleanField()
    join_date = models.DateField(auto_now_add=True)

    class Meta:
        db_table = "users"
