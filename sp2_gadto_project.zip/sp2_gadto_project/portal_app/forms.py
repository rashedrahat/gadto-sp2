from django import forms

genders = [
    ('', 'Choose Your Gender'),
    ('female', 'Female'),
    ('male', 'Male'),
    ('other', 'Other'),
]


class SignUp(forms.Form):
    user_name = forms.CharField(max_length=10)
    name = forms.CharField(max_length=50)
    email = forms.EmailField()
    phone_number = forms.CharField(min_length=14, max_length=14)
    gender = forms.CharField(
        label='What is your gender?', widget=forms.Select(choices=genders))
    date_of_birth = forms.CharField(
        widget=forms.widgets.DateTimeInput(attrs={"type": "date"}))
    password = forms.CharField(widget=forms.PasswordInput)


class SignIn(forms.Form):
    user_name = forms.CharField(max_length=10)
    password = forms.CharField(widget=forms.PasswordInput)
