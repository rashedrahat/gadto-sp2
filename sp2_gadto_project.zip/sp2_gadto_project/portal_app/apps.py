from django.apps import AppConfig


class PortalAppConfig(AppConfig):
    name = 'portal_app'
