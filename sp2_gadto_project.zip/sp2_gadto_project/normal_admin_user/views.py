from django.contrib import messages
from django.shortcuts import render, redirect

# Create your views here.
from general_user.forms import ProfileUpdateForm
from portal_app.models import User


def dashboard(request):
    try:
        logged_in_user_id = request.session['user_id']
        user = User.objects.get(id=logged_in_user_id)
        return render(request, 'na_dashboard.html', {"title": "Dashboard", "user": user})
    except KeyError:
        return redirect('log-in')


def profile_info(request):
    try:
        logged_in_user_id = request.session['user_id']
        user = User.objects.get(id=logged_in_user_id)
        if request.method == 'POST':
            form = ProfileUpdateForm(request.POST, instance=user)
            if form.is_valid():
                form.save()
                messages.success(request, f'Your profile has been updated!')
                return redirect('normal-admin-user-profile-info')

        else:
            form = ProfileUpdateForm(instance=user)

        return render(request, 'na_profile_info.html', {"title": "Profile Info", "user": user, "form": form})
    except KeyError:
        return redirect('log-in')


def manage_users(request):
    try:
        logged_in_user_id = request.session['user_id']
        user = User.objects.get(id=logged_in_user_id)

        try:
            users = User.objects.filter(is_admin=0, is_staff=0)
        except Exception as e:
            admins = None

        return render(request, 'reg_users.html', {"title": "Manage users", "users": users, "user": user})

    except KeyError:
        return redirect('log-in')


def active_change(request, id):
    try:
        logged_in_user = request.session['user_id']
        if logged_in_user:
            user = User.objects.get(id=id)
            if user.is_active == 1:
                user.is_active = 0
                user.save()
                messages.success(
                    request, f'Successfully blocked user.')
                return redirect('reg-users')
            else:
                user.is_active = 1
                user.save()
                messages.success(
                    request, f'Successfully unblocked user.')
                return redirect('reg-users')

    except KeyError:
        return redirect('log-in')


def delete_user(request, id):
    try:
        logged_in_user = request.session['user_id']
        if logged_in_user:
            user = User.objects.get(id=id)
            user.delete()
            messages.success(
                request, f'Successfully deleted user.')
            return redirect('reg-users')

    except KeyError:
        return redirect('log-in')
