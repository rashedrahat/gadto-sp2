from django.apps import AppConfig


class NormalAdminUserConfig(AppConfig):
    name = 'normal_admin_user'
