from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.dashboard, name="normal-admin-user-dashboard"),
    path('profile-info/', views.profile_info, name="normal-admin-user-profile-info"),
    path('manage-users/', views.manage_users, name="reg-users"),
    path('manage-users/<int:id>/change-active/', views.active_change, name="active-change"),
    path('manage-users/<int:id>/delete/', views.delete_user, name="delete-user"),

]