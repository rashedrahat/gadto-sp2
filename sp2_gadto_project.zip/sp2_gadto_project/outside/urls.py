from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name="gadto-home"),
    path('gu/', include('general_user.urls')),
    path('sa/', include('super_admin_user.urls')),
    path('na/', include('normal_admin_user.urls')),
    path('ajax/<str:gadget_name>/<str:e_website_name>/', views.gadget_e_website_specification,
         name="gadget-e-website-specification"),
    path('<str:gad_cat>/<str:brand_cat>/', views.gadget_list, name="gadget-list"),
    path('<str:gad_cat>/<str:brand_cat>/<str:gadget_name>/', views.gadget_info, name="gadget-info"),
    # path('ajax/<str:gadget_name>/<str:e_website_name>/', views.gadget_e_website_specification,
    #      name="gadget-e-website-specification")

]
