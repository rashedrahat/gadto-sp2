from django.http import JsonResponse
from django.shortcuts import render
from .models import GadgetInfo


# Create your views here.


def home(request):
    try:
        gadgets_cat = GadgetInfo.objects.values('gadget_category').distinct().order_by(
            'gadget_category')
        brands_cat = GadgetInfo.objects.values(
            'gadget_brand', 'gadget_category').distinct().order_by('gadget_brand')
        # print(brands_cat)
        # print(len(gadgets_cat))
        # for gadget_cat in gadgets_cat:
        #     print(gadget_cat['parent_category_name'])
        return render(request, 'index.html', {"title": "Home", "gadgets_cat": gadgets_cat, "brands_cat": brands_cat})
    except KeyError:
        pass


def gadget_list(request, gad_cat, brand_cat):
    try:
        # print("I see")
        gadgets_cat = GadgetInfo.objects.values('gadget_category').distinct().order_by(
            'gadget_category')
        brands_cat = GadgetInfo.objects.values(
            'gadget_brand', 'gadget_category').distinct().order_by('gadget_brand')
        gadgets = GadgetInfo.objects.filter(
            gadget_category=gad_cat, gadget_brand=brand_cat).order_by('gadget_name')
        # print(len(gadgets))
        return render(request, 'gadgets.html',
                      {"title": "Gadgets", "gadgets_cat": gadgets_cat, "brands_cat": brands_cat, "gad_cat": gad_cat,
                       "brand_cat": brand_cat, "gadgets": gadgets})
    except KeyError:
        pass


def gadget_info(request, gad_cat, brand_cat, gadget_name):
    try:
        # print("I see")
        gadgets_cat = GadgetInfo.objects.values('gadget_category').distinct().order_by(
            'gadget_category')
        brands_cat = GadgetInfo.objects.values(
            'gadget_brand', 'gadget_category').distinct().order_by('gadget_brand')
        gadget = GadgetInfo.objects.get(
            gadget_category=gad_cat, gadget_brand=brand_cat, gadget_name=gadget_name)
        # print(gadget)
        similar_gadgets = GadgetInfo.objects.filter(gadget_category=gadget.gadget_category,
                                                    gadget_brand=gadget.gadget_brand).exclude(
            gadget_name=gadget.gadget_name)
        return render(request, 'gadget.html',
                      {"title": "Gadget Info", "gadgets_cat": gadgets_cat, "brands_cat": brands_cat, "gad_cat": gad_cat,
                       "brand_cat": brand_cat, "gadget_name": gadget_name, "gadget": gadget,
                       "similar_gadgets": similar_gadgets})
    except KeyError:
        pass


def gadget_e_website_specification(request, gadget_name, e_website_name):
    try:
        # print("I see..")
        if e_website_name == "Star Tech":
            gadget_specification = GadgetInfo.objects.values('specification_1').get(gadget_name=gadget_name)
            # print(gadget_specification)
            data = {
                "specification": gadget_specification
            }
            return JsonResponse(data)

        else:
            gadget_specification = GadgetInfo.objects.values('specification_2').get(gadget_name=gadget_name)
            # print(gadget_specification)
            data = {
                "specification": gadget_specification
            }
            return JsonResponse(data)

    except KeyError:
        pass
