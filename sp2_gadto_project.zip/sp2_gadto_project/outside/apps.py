from django.apps import AppConfig


class OutsideConfig(AppConfig):
    name = 'outside'
