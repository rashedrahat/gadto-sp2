from django.db import models

# Create your models here.


class GadgetInfo(models.Model):
    gadget_name = models.CharField(max_length=152, null=True)
    gadget_category = models.CharField(max_length=11, null=True)
    gadget_brand = models.CharField(max_length=12, null=True)
    img_url_1 = models.CharField(max_length=167, null=True)
    img_url_2 = models.CharField(max_length=140, null=True)
    specification_1 = models.CharField(max_length=185, null=True)
    specification_2 = models.CharField(max_length=1476, null=True)
    price_1 = models.CharField(max_length=8, null=True)
    price_2 = models.CharField(max_length=10, null=True)
    e_com_website_1 = models.CharField(max_length=9, null=True)
    e_com_website_2 = models.CharField(max_length=5, null=True)
    gad_url_1 = models.CharField(max_length=94, null=True)
    gad_url_2 = models.CharField(max_length=281, null=True)
    gad_cat_status = models.BooleanField(max_length=1, null=False, default=True)
    brand_status = models.BooleanField(max_length=1, null=False, default=True)
    ecw_1_status = models.BooleanField(max_length=1, null=False, default=True)
    ecw_2_status = models.BooleanField(max_length=1, null=False, default=True)

    class Meta:
        db_table = "gadgets_info"
