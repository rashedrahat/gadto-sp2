from django.contrib import messages
from django.shortcuts import render, redirect

# Create your views here.
from general_user.forms import ProfileUpdateForm
from portal_app.forms import SignUp
from portal_app.models import User


def dashboard(request):
    try:
        logged_in_user_id = request.session['user_id']
        user = User.objects.get(id=logged_in_user_id)
        return render(request, 'sa_dashboard.html', {"title": "Dashboard", "user": user})
    except KeyError:
        return redirect('log-in')


def profile_info(request):
    try:
        logged_in_user_id = request.session['user_id']
        user = User.objects.get(id=logged_in_user_id)
        if request.method == 'POST':
            form = ProfileUpdateForm(request.POST, instance=user)
            if form.is_valid():
                form.save()
                messages.success(request, f'Your profile has been updated!')
                return redirect('super-admin-user-profile-info')

        else:
            form = ProfileUpdateForm(instance=user)

        return render(request, 'sa_profile_info.html', {"title": "Profile Info", "user": user, "form": form})
    except KeyError:
        return redirect('log-in')


def create_admin(request):
    try:
        logged_in_user_id = request.session['user_id']
        user = User.objects.get(id=logged_in_user_id)
        if request.method == 'POST':
            form = SignUp(request.POST)
            if form.is_valid():
                user = User(
                    username=form.cleaned_data.get('user_name'),
                    name=form.cleaned_data.get('name'),
                    email=form.cleaned_data.get('email'),
                    phonenumber=form.cleaned_data.get('phone_number'),
                    gender=form.cleaned_data.get('gender'),
                    dob=form.cleaned_data.get('date_of_birth'),
                    password=form.cleaned_data.get('password'),
                    is_admin=1,
                    is_staff=1,
                    is_active=1

                )
                try:
                    user.save()
                    username = form.cleaned_data.get('user_name')
                    messages.success(
                        request, f'Successfully created an admin.')
                    return redirect('manage-admins')
                except Exception as e:
                    messages.warning(
                        request, f'The username or email is already taken.')
                    return redirect('create-admin')

        else:
            form = SignUp()
    except KeyError:
        return redirect('log-in')

    return render(request, 'create_admin.html', {"title": "Create admin", "form": form, "user": user})


def manage_admins(request):
    try:
        logged_in_user_id = request.session['user_id']
        user = User.objects.get(id=logged_in_user_id)

        try:
            admins = User.objects.filter(is_staff=1)
        except Exception as e:
            admins = None

        return render(request, 'manage_admins.html', {"title": "Manage admins", "admins": admins, "user": user})

    except KeyError:
        return redirect('log-in')


def manage_users(request):
    try:
        logged_in_user_id = request.session['user_id']
        user = User.objects.get(id=logged_in_user_id)

        try:
            users = User.objects.filter(is_admin=0, is_staff=0)
        except Exception as e:
            admins = None

        return render(request, 'manage_users.html', {"title": "Manage users", "users": users, "user": user})

    except KeyError:
        return redirect('log-in')


# def block_admin(request, id):
#     try:
#         logged_in_user = request.session['user_id']
#         if logged_in_user:
#             admin = User.objects.get(id=id)
#             admin.is_active = 0
#             admin.save()
#             messages.success(
#                 request, f'Successfully blocked admin.')
#             return redirect('manage-admins')
#
#     except KeyError:
#         return redirect('log-in')


# def unblock_admin(request, id):
#     try:
#         logged_in_user = request.session['user_id']
#         if logged_in_user:
#             admin = User.objects.get(id=id)
#             admin.is_active = 1
#             admin.save()
#             messages.success(
#                 request, f'Successfully unblocked admin.')
#             return redirect('manage-admins')
#
#     except KeyError:
#         return redirect('log-in')


def change_active(request, id):
    try:
        logged_in_user = request.session['user_id']
        if logged_in_user:
            admin = User.objects.get(id=id)
            if admin.is_active:
                admin.is_active = 0
                admin.save()
                messages.success(
                    request, f'Successfully blocked admin.')
                return redirect('manage-admins')
            else:
                admin.is_active = 1
                admin.save()
                messages.success(
                    request, f'Successfully unblocked admin.')
                return redirect('manage-admins')

    except KeyError:
        return redirect('log-in')


def active_change(request, id):
    try:
        logged_in_user = request.session['user_id']
        if logged_in_user:
            user = User.objects.get(id=id)
            if user.is_active == 1:
                user.is_active = 0
                user.save()
                messages.success(
                    request, f'Successfully blocked user.')
                return redirect('manage-users')
            else:
                user.is_active = 1
                user.save()
                messages.success(
                    request, f'Successfully unblocked user.')
                return redirect('manage-users')

    except KeyError:
        return redirect('log-in')


def delete_admin(request, id):
    try:
        logged_in_user = request.session['user_id']
        if logged_in_user:
            admin = User.objects.get(id=id)
            admin.delete()
            messages.success(
                request, f'Successfully deleted admin.')
            return redirect('manage-admins')

    except KeyError:
        return redirect('log-in')


def delete_user(request, id):
    try:
        logged_in_user = request.session['user_id']
        if logged_in_user:
            user = User.objects.get(id=id)
            user.delete()
            messages.success(
                request, f'Successfully deleted user.')
            return redirect('manage-users')

    except KeyError:
        return redirect('log-in')
