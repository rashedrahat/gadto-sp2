from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.dashboard, name="super-admin-user-dashboard"),
    path('profile-info/', views.profile_info, name="super-admin-user-profile-info"),
    path('create-admin/', views.create_admin, name="create-admin"),
    path('manage-admins/', views.manage_admins, name="manage-admins"),
    # path('manage-admins/<int:id>/block/', views.block_admin, name="block-admin"),
    # path('manage-admins/<int:id>/unblock/', views.unblock_admin, name="unblock-admin"),
    path('manage-admins/<int:id>/change-active/', views.change_active, name="change-active"),
    path('manage-admins/<int:id>/delete/', views.delete_admin, name="delete-admin"),
    path('manage-users/', views.manage_users, name="manage-users"),
    path('manage-users/<int:id>/change-active/', views.active_change, name="active-change"),
    path('manage-users/<int:id>/delete/', views.delete_user, name="delete-user"),

]