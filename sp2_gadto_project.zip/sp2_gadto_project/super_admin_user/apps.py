from django.apps import AppConfig


class SuperAdminUserConfig(AppConfig):
    name = 'super_admin_user'
