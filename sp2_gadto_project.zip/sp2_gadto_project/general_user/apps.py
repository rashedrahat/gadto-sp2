from django.apps import AppConfig


class GeneralUserConfig(AppConfig):
    name = 'general_user'
