from portal_app.forms import SignUp
from django import forms

from portal_app.models import User


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'phonenumber', 'gender', 'dob', 'password']
        widgets = {
            'username': forms.TextInput(attrs={'readonly': 'readonly'}),
            'gender': forms.TextInput(attrs={'readonly': 'readonly'}),
            'dob': forms.TextInput(attrs={'readonly': 'readonly'})
        }