from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.dashboard, name="general-user-dashboard"),
    path('profile-info/', views.profile_info, name="general-user-profile-info"),
]