from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from portal_app.models import User
from .forms import ProfileUpdateForm


# Create your views here.


def dashboard(request):
    try:
        logged_in_user_id = request.session['user_id']
        user = User.objects.get(id=logged_in_user_id)
        return render(request, 'dashboard.html', {"title": "Dashboard", "user": user})
    except KeyError:
        return redirect('log-in')


def profile_info(request):
    try:
        logged_in_user_id = request.session['user_id']
        user = User.objects.get(id=logged_in_user_id)
        if request.method == 'POST':
            form = ProfileUpdateForm(request.POST, instance=user)
            if form.is_valid():
                form.save()
                messages.success(request, f'Your profile has been updated!')
                return redirect('general-user-profile-info')

        else:
            form = ProfileUpdateForm(instance=user)

        return render(request, 'profile_info.html', {"title": "Profile Info", "user": user, "form": form})
    except KeyError:
        return redirect('log-in')
